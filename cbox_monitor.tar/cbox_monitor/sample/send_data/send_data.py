import socket
import time
import json
import datetime
import numpy as np

# サーバーの設定
# SERVER_HOST = '127.0.0.1'  # サーバーが動作するホスト
SERVER_HOST = "node-server"  # サーバーが動作するホスト
SERVER_PORT = 65432  # サーバーのポート

MAX_RETRIES = 10
RETRY_INTERVAL = 5

# ローレンツ方程式のパラメータ
sigma = 10.0
rho = 28.0
beta = 8.0 / 3.0

# 初期値（適当に設定）
x, y, z = 20.0, 25.0, 30.0
dt = 0.01  # 時間ステップ


def handle_connection():
    global x, y, z
    retries = 0

    while retries < MAX_RETRIES:

        try:
            # ソケットの設定
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            print(f"接続試行 {retries + 1}/{MAX_RETRIES}...")
            sock.connect((SERVER_HOST, SERVER_PORT))
            print("サーバーに接続成功！")

            # 送信ループ
            while True:
                # ローレンツ方程式によるカオスな変動
                dx = sigma * (y - x) * dt
                dy = (x * (rho - z) - y) * dt
                dz = (x * y - beta * z) * dt

                x += dx
                y += dy
                z += dz

                # 温度と湿度の変動（スケール調整）
                temperature = 15 + (x % 15)  # 15 〜 30度
                humidity = 30 + (abs(y) % 40)  # 30 〜 70%

                # ランダムなカラー（カオス変動に基づく）
                # color_options = ['#FF0000', '#00FF00', '#0000FF']
                color_options = ["#ffffff", "#ffffff", "#ffffff"]
                bgcolor_options = ["#c41a30", "#2f4f4f", "#092237"]
                color_index = int(abs(z) % 3)  # 0, 1, 2 の範囲にする
                color = color_options[color_index]
                bgcolor = bgcolor_options[color_index]

                # RSSI
                rssi_value = np.random.normal(loc=-65, scale=10)
                rssi_value = np.clip(rssi_value, -90, -30)

                voltage_value = np.random.normal(loc=3.7, scale=0.2)
                voltage_value = np.clip(voltage_value, 3.0, 4.2)

                vibration_value = np.random.normal(loc=8.61, scale=0.7)
                vibration_value = max(6.8, min(vibration_value, 10.9))

                co2_value = np.random.normal(loc=700, scale=100)
                co2_value = max(400, min(co2_value, 1000))

                # データ取得日時
                date_s = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f")

                # # 送信データを作成
                # data = {
                #     'temperature': round(temperature, 2),
                #     'humidity': round(humidity, 2),
                #     'color': color,
                #     'bgcolor': bgcolor,
                #     'date': date_s
                # }

                # # JSON形式で送信
                # sock.sendall(json.dumps(data).encode('utf-8'))
                # print(f"送信データ: {data}")

                # # 5秒ごとに送信
                # time.sleep(5)

                # センサーデータ構造
                sensor_data = {
                    "Command": "SetSensorChildData",
                    "Data": {
                        "ParentNumber": 1,
                        "ChildNumber": 2,
                        "SensorChildName": "センサ1",
                        "SensorChildDatatime": date_s,
                        "SensorChildData": [
                            {
                                "SensorChildDataName": "温度",
                                "SensorChildDataKind": "temperature",
                                "SensorChildDataValue": temperature,
                                "SensorChildDataUnit": "℃",
                                "SensorChildDataUpperWarning": 35.0,
                                "SensorChildDataLowerWarning": 0.0,
                                "SensorChildDataUpperCaution": 30.0,
                                "SensorChildDataLowerCaution": 5.0,
                                "SensorChildWarningThresholdOver": temperature > 35.0,
                                "SensorChildCautionThresholdOver": temperature > 30.0,
                            },
                            {
                                "SensorChildDataName": "振動",
                                "SensorChildDataKind": "vibration",
                                "SensorChildDataValue": vibration_value,
                                "SensorChildDataUnit": "㎨",
                                "SensorChildDataUpperWarning": 16.2,
                                "SensorChildDataLowerWarning": 0.0,
                                "SensorChildDataUpperCaution": 13.8,
                                "SensorChildDataLowerCaution": 0.0,
                                "SensorChildWarningThresholdOver": vibration_value > 16.2,
                                "SensorChildCautionThresholdOver": vibration_value > 13.8,
                            },
                            {
                                "SensorChildDataName": "湿度",
                                "SensorChildDataKind": "humidity",
                                "SensorChildDataValue": humidity,
                                "SensorChildDataUnit": "%",
                                "SensorChildDataUpperWarning": 80.0,
                                "SensorChildDataLowerWarning": 0.0,
                                "SensorChildDataUpperCaution": 70.0,
                                "SensorChildDataLowerCaution": 0.0,
                                "SensorChildWarningThresholdOver": humidity > 80.0,
                                "SensorChildCautionThresholdOver": humidity > 70.0,
                            },
                            {
                                "SensorChildDataName": "CO2濃度",
                                "SensorChildDataKind": "co2_concentration",
                                "SensorChildDataValue": co2_value,
                                "SensorChildDataUnit": "ppm",
                                "SensorChildDataUpperWarning": 1000,
                                "SensorChildDataLowerWarning": 0.0,
                                "SensorChildDataUpperCaution": 700,
                                "SensorChildDataLowerCaution": 0.0,
                                "SensorChildWarningThresholdOver": co2_value > 1000,
                                "SensorChildCautionThresholdOver": co2_value > 700,
                            },
                        ],
                        "SensorChildCondition": "通信中",
                        "SensorChildRSSI": rssi_value,
                        "SensorChildBatteryLevel": voltage_value,
                    },
                    # 元のデータ
                    "temperature": round(temperature, 2),
                    "humidity": round(humidity, 2),
                    "color": color,
                    "bgcolor": bgcolor,
                    "date": date_s,
                }

                # JSON送信
                sock.sendall(json.dumps(sensor_data).encode("utf-8"))
                print(
                    f"送信データ: {json.dumps(sensor_data, ensure_ascii=False, indent=2)}"
                )

                # 5秒ごとに送信
                time.sleep(5)

        except (socket.error, ConnectionError) as e:
            print(f"接続失敗: {e}")
            retries += 1
            if retries < MAX_RETRIES:
                print(f"{RETRY_INTERVAL}秒後に再試行します...")
                time.sleep(RETRY_INTERVAL)
            else:
                print("最大リトライ回数に達しました。終了します。")
                return


handle_connection()
