<!--
  @file Modal.svelte
  @description モーダルダイアログを表示するコンポーネント。タイトル、メッセージ、OK/キャンセルのコールバックを受け取る。
  @author FSI
  @date 2025-06-12
-->

<script>
  /**
   * モーダルに表示するタイトル文字列
   * @type {string}
   */
  export let title = '';

  /**
   * モーダルに表示するメッセージ本文
   * @type {string}
   */
  export let message = '';

  /**
   * OKボタンがクリックされたときに呼び出されるコールバック関数
   * @type {() => void}
   */
  export let onConfirm;

  /**
   * キャンセルボタンがクリックされたときに呼び出されるコールバック関数
   * @type {() => void}
   */
  export let onCancel;

  /**
   * Escapeキーが押されたときにモーダルを閉じる処理を実行
   * @param {KeyboardEvent} event - キーボードイベント
   * @returns {void}
   */
  const handleKeydown = (event) => {
    if (event.key === 'Escape') {
      onCancel?.();
    }
  };

  import { onMount, onDestroy } from 'svelte';

  /**
   * コンポーネントのマウント時に Escapeキーのイベントリスナーを登録
   * @returns {void}
   */
  onMount(() => {
    window.addEventListener('keydown', handleKeydown);
  });

  /**
   * コンポーネントのアンマウント時にイベントリスナーを解除
   * @returns {void}
   */
  onDestroy(() => {
    window.removeEventListener('keydown', handleKeydown);
  });
</script>

<!--*
 * @section モーダル表示領域
 * @description 画面全体を覆う半透明のオーバーレイ。モーダルを中央に表示する。
 *-->
<div class="modal-overlay">
	<div class="modal" role="dialog" aria-modal="true" aria-label="確認ダイアログ">
		<h2 class="modal-title">{title}</h2>
		<p class="modal-message">{message}</p>
		<div class="button-group">
			<button type="button" on:click={onConfirm}>OK</button>
			<button type="button" on:click={onCancel}>キャンセル</button>
		</div>
	</div>
</div>

<style>
	/* 背景オーバーレイ */
	.modal-overlay {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		justify-content: center;
		align-items: center;
	}

	/* モーダル本体 */
	.modal {
		background-color: white;
		padding: 2rem;
		border-radius: 8px;
		box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
		max-width: 400px;
		width: 90%;
	}

	/* タイトルのスタイル */
	.modal-title {
		margin: 0 0 1rem;
		font-size: 1.5rem;
		font-weight: bold;
		color: #333;
	}

	/* メッセージのスタイル */
	.modal-message {
		margin-bottom: 1.5rem;
		font-size: 1rem;
		color: #555;
		padding-left: 1.5rem; /* ← ここで右寄せ感を出す */
	}

	/* ボタン配置 */
	.button-group {
		display: flex;
		justify-content: flex-end;
		gap: 0.5rem;
	}

	/* ボタンのスタイル */
	.button-group button {
		padding: 0.5rem 1rem;
		cursor: pointer;
		font-size: 1rem;
	}
</style>
