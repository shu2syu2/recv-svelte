<script>
	import { writable } from 'svelte/store';
	import AccordionMenu from '$lib/components/AccordionMenu.svelte';
	import { SENSOR_NAMES } from '$lib/constants';

	/**
	 * メニュー項目の定義
	 * 各メニューには名前、タグ、アイコン、サブメニューとそのリンク先が含まれる
	 *
	 * @type {Array<{
	 *   name: string,
	 *   nameTag: string,
	 *   nameIconOpen: string,
	 *   nameIconClose: string,
	 *   subMenu: string[],
	 *   subMenuPage: string[]
	 * }>}
	 */
	let menuItems = [
		{
			name: 'モニタリング',
			nameTag: 'monitoring',
			nameIconOpen: '/binoculars-open.svg',
			nameIconClose: '/binoculars-close.svg',
			subMenu: ['マップビュー', 'センサ一覧', 'センサ詳細', 'アラーム履歴'],
			subMenuPage: ['/monitoring/map', '/error', '/monitoring/sensors', '/error']
		},
		{
			name: '本体設定',
			nameTag: 'settings',
			nameIconOpen: '/power-button-open.svg',
			nameIconClose: '/power-button-close.svg',
			subMenu: SENSOR_NAMES.filter((sensor) => sensor.use).map((sensor) => sensor.name),
			subMenuPage: SENSOR_NAMES
					.filter(sensor => sensor.use)
					.map(sensor => `/monitoring/sensors/graphs/${sensor.key}`)
		},
		{
			name: '接続環境設定',
			nameTag: 'environment-settings',
			nameIconOpen: '/environment-open.svg',
			nameIconClose: '/environment-close.svg',
			subMenu: ['接続環境設定-1', '接続環境設定-2'],
			subMenuPage: ['/error', '/error']
		},
		{
			name: '出力設定',
			nameTag: 'output-settings',
			nameIconOpen: '/bugle-open.svg',
			nameIconClose: '/bugle-close.svg',
			subMenu: ['出力-1', '出力-2'],
			subMenuPage: ['/error', '/error']
		},
		{
			name: 'データ設定',
			nameTag: 'data-settings',
			nameIconOpen: '/note-open.svg',
			nameIconClose: '/note-close.svg',
			subMenu: ['閾値設定', 'ダッシュボード'],
			subMenuPage: ['/error', '/settings/dashboard']
		}
	];

	/**
	 * iframeの表示URL（初期状態は空）
	 * @type {import('svelte/store').Writable<string>}
	 */
	const iframeSrc = writable('');

	/**
	 * 現在開いているメニューのタグ
	 * @type {import('svelte/store').Writable<string>}
	 */
	const openMenu = writable('');

	/**
	 * 選択されたサブメニュー情報
	 * @type {import('svelte/store').Writable<{ menuTag: string, subItem: string }>}
	 */
	const selectedSubItem = writable({ menuTag: '', subItem: '' });

	/**
	 * メニューの開閉を切り替える
	 *
	 * @param {string} menuName - 開くメニューのタグ名
	 */
	const toggleMenu = (menuName) => {
		openMenu.set(menuName);
	};

	/**
	 * iframeの表示URLと選択中のサブメニューを設定する
	 *
	 * @param {string} path - iframeに表示するパス
	 * @param {string} menuTag - メニュータグ
	 * @param {string} subItem - サブメニュー名
	 */
	const setIframeSrc = (path, menuTag, subItem) => {
		iframeSrc.set(path);
		selectedSubItem.set({ menuTag, subItem });
	};
</script>

<!--
  @component SidebarWithIframe
  @description アコーディオンメニューとiframe表示を組み合わせたレイアウトコンポーネント。
-->
<div class="container">
	<div class="sidebar">
		{#each menuItems as menuItem}
			<AccordionMenu
				{menuItem}
				isOpen={$openMenu === menuItem.nameTag}
				{toggleMenu}
				{setIframeSrc}
				selectedSubItem={$selectedSubItem}
			/>
		{/each}
	</div>
	<div class="content">
		{#if $iframeSrc !== ''}
			<iframe src={$iframeSrc} title="画面表示"></iframe>
		{/if}
	</div>
</div>

<style>
	/* 全体の余白とスクロール設定をリセット */
	:global(html),
	:global(body) {
		margin: 0;
		padding: 0;
		height: 100%;
		overflow: hidden;
	}

	/* 全体レイアウトのコンテナ */
	.container {
		display: flex;
		height: 100vh;
		overflow: hidden;
	}

	/* サイドバーのスタイル */
	.sidebar {
		width: 200px;
		padding: 10px;
		border-right: 1px solid #ccc;
		font-weight: bold;
	}

	/* メインコンテンツ領域のスタイル */
	.content {
		flex-grow: 1;
		padding: 10px;
	}

	/* iframeのスタイル */
	iframe {
		width: 100%;
		height: 100%;
		border: none;
		display: block;
	}
</style>
