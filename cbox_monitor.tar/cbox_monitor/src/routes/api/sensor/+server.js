import { json } from '@sveltejs/kit';
import 'dotenv/config';

/**
 * センサーデータを取得して JSON レスポンスとして返す GET ハンドラ
 * 環境変数 SENSOR_URL を参照し、外部 API からデータを取得します。
 *
 * @returns {Promise<Response>} センサーデータの JSON またはエラーレスポンス
 */
export async function GET() {
	try {
		const url = process.env.SENSOR_URL;
		if (!url) {
			console.error('環境変数 SENSOR_URL が未定義です');
			return new Response('内部設定エラー', { status: 500 });
		}

		const res = await fetch(url);
		const data = await res.json();
		return json(data);
	} catch (err) {
		console.error('API取得失敗:', process.env.SENSOR_URL, err);
		return new Response('データ取得失敗', { status: 500 });
	}
}