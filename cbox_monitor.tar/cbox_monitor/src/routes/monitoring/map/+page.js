/**
 * このページまたはレイアウトでサーバーサイドレンダリング（SSR）を無効にする設定。
 *
 * @constant
 * @type {boolean}
 * @default false
 * @description この設定が `false` の場合、該当ページはクライアントサイドでのみレンダリングされます。
 *              サーバーではHTMLを生成せず、JavaScriptがクライアントで実行されて初めて表示されます。
 *
 * @note SEOが不要なページ（例：ダッシュボード、管理画面など）に適しています。
 *       SSRを無効にすると、初期表示が遅くなる可能性があるため注意が必要です。
 */
export const ssr = false;
