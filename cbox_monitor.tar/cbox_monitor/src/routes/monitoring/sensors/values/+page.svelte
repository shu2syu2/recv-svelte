<script>
	import { sensorData } from '$lib/stores/sensorStore';
	import { onMount, onDestroy } from 'svelte';
	import '$lib/styles/global.css';
	import { page } from '$app/stores';
	import { formatDecimal } from '$lib/utils/commonUtils';

	// 表示用のセンサーデータ
	let sensorDisplayData = {};

	// URLパラメータから取得するセンサー名
	let sensorName = 'defaultSensor';

	onMount(() => {
		// URLパラメータからセンサー名を取得
		const unsubscribePage = page.subscribe(($page) => {
			sensorName = $page.url.searchParams.get('sensorName') || 'defaultSensor';
		});

		// sensorData ストアを購読して表示データを更新
		const unsubscribeSensor = sensorData.subscribe((value) => {
			const sensorValues = value?.Data?.SensorChildData ?? [];

			// 該当センサーのデータを取得
			sensorDisplayData =
				sensorValues.find((item) => item.SensorChildDataName === sensorName) ?? {};

			// 値を丸めて表示用に加工
			if (sensorDisplayData.SensorChildDataValue != null) {
				sensorDisplayData.SensorChildDataValue = formatDecimal(
					sensorDisplayData.SensorChildDataValue
				);
			}
		});

		// コンポーネント破棄時に購読解除
		onDestroy(() => {
			unsubscribePage();
			unsubscribeSensor();
		});
	});
</script>

<!-- センサーデータの表示 -->
<div class="sensor_layout">
	<p class="second-lavel">{sensorDisplayData.SensorChildDataName}</p>
	<p class="second-value">
		{sensorDisplayData.SensorChildDataValue}{sensorDisplayData.SensorChildDataUnit}
	</p>
	<p>
		{#if sensorDisplayData.SensorChildDataUpperCaution != null}
			<span class="third-warn">
				警戒値：{sensorDisplayData.SensorChildDataUpperWarning}{sensorDisplayData.SensorChildDataUnit}以上&emsp;
			</span>
		{/if}
		{#if sensorDisplayData.SensorChildDataUpperWarning != null}
			<span class="third-caut">
				危険値：{sensorDisplayData.SensorChildDataUpperCaution}{sensorDisplayData.SensorChildDataUnit}以上&emsp;
			</span>
		{/if}
		{#if sensorDisplayData.SensorChildWarningThresholdOver}
			<span class="threshold-over">閾値超過中</span>
		{/if}
	</p>
</div>

<style>
	/* 全体の余白とスクロール設定をリセット */
	:global(html),
	:global(body) {
		margin: 0;
		padding: 0;
		height: 100%;
		overflow: hidden;
		font-size: 16px;
	}

	/* センサ詳細ページ */
	/* 閾値表示エリア */
	.sensor_layout {
		background-color: white;
		text-align: center;
	}

	/* 閾値ラベル */
	.second-lavel {
		color: #00817e;
		font-size: 2em;
		font-weight: bold;
		line-height: 1.2;
	}

	/* 閾値値 */
	.second-value {
		color: black;
		font-size: 2em;
		font-weight: bold;
		line-height: 1.2;
	}

	/* 警戒 */
	.third-warn {
		color: #ffe600;
		font-size: 1.5em;
		font-weight: bold;
		line-height: 1.2;
	}

	/* 危険 */
	.third-caut {
		color: red;
		font-size: 1.5em;
		font-weight: bold;
		line-height: 1.2;
	}
</style>
