<script>
	import '$lib/styles/global.css';
	import FullCalendar from '$lib/components/FullCalendar.svelte';
	import { getMonthStartEnd } from '$lib/utils/commonUtils';
	import { CONSTANTS } from '$lib/constants';
	import { clickedEvent } from '$lib/stores/calencarStore';

	/**
	 * 選択中の期間タイプ（初期値：月別）
	 * @type {string}
	 */
	let selectedTypePeriod = CONSTANTS.TYPES_PERIOD[1].label;

	/**
	 * 選択中の集計タイプ（初期値：合計）
	 * @type {string}
	 */
	let selectedTypeAggregation = CONSTANTS.TYPES_AGG[0].label;

	/**
	 * グラフ表示フラグ
	 * @type {boolean}
	 */
	let showGraph = false;

	/**
	 * メニュー階層の定義
	 * @type {Array<{name: string, nameTag: string, listItem: string[]}>}
	 */
	let menuHierarchyItems = [
		{
			name: '階層1',
			nameTag: 'hierarchy1',
			listItem: ['(1)グループ１', '(2)照明', '(3)製造']
		},
		{
			name: '階層2',
			nameTag: 'hierarchy2',
			listItem: ['選択しない', '(1)グループ１', '(2)照明', '(3)製造']
		},
		{
			name: '階層3',
			nameTag: 'hierarchy3',
			listItem: ['選択しない', '(1)グループ１', '(2)照明', '(3)製造']
		}
	];

	/**
	 * グラフの種類一覧
	 * @type {Array<{index: number, value: string, icon: string}>}
	 */
	const graphTypes = [
		{ index: 0, value: 'bar', icon: '/chart-bar.svg' },
		{ index: 1, value: 'line', icon: '/chart-line.svg' },
		{ index: 2, value: 'stacked', icon: '/chart-bar-stacked.svg' }
	];

	/**
	 * 選択中のグラフタイプのインデックス
	 * @type {number}
	 */
	let selectedGraph = graphTypes[0].index;

	/**
	 * 選択された階層項目
	 * @type {string[]}
	 */
	let selectedHierarchyItems = [
		menuHierarchyItems[0].listItem[0],
		menuHierarchyItems[1].listItem[0],
		menuHierarchyItems[2].listItem[0]
	];

	/** @type {{ start: string, end: string }} */
	const range = getMonthStartEnd();
	let selectedFrom = range.start;
	let selectedTo = range.end;

	/**
	 * FullCalendarコンポーネントの参照
	 * @type {import("svelte").SvelteComponent}
	 */
	let calendarComponent;

	/**
	 * カレンダーに表示するイベント一覧
	 * @type {Array<Object>}
	 */
	let events = [];

	/**
	 * 情報表示用iframeのURL
	 * @type {string}
	 */
	let iframeSrcInformation = `/settings/dashboard/information?date=${selectedFrom}`;

	/**
	 * グラフ表示用iframeのURL
	 * @type {string}
	 */
	let iframeSrcGraph = getIframeSrcGraph(
		selectedFrom,
		selectedTo,
		getPeriodType(selectedTypePeriod),
		getAggregationType(selectedTypeAggregation),
		getGraphType(selectedGraph)
	);

	/**
	 * 日本語の期間オプションを英語の期間タイプに変換
	 * @param {string} option - 期間の選択肢
	 * @returns {string} 英語の期間タイプ
	 */
	function getPeriodType(option) {
		const found = CONSTANTS.TYPES_PERIOD.find((item) => item.label === option);
		return found ? found.key : 'monthly';
	}

	/**
	 * 日本語の集計タイプを英語に変換
	 * @param {string} option - 集計タイプの選択肢
	 * @returns {string} 英語の集計タイプ
	 */
	function getAggregationType(option) {
		const found = CONSTANTS.TYPES_AGG.find((item) => item.label === option);
		return found ? found.key : 'grouped';
	}

	/**
	 * グラフタイプのインデックスを文字列に変換
	 * @param {number} option - グラフタイプのインデックス
	 * @returns {string} グラフの種類
	 */
	function getGraphType(option) {
		const found = graphTypes.find((item) => item.index === option);
		return found ? found.value : 'bar';
	}

	/**
	 * グラフ表示用のiframe URLを生成
	 * @param {string} start - 表示開始日
	 * @param {string} end - 表示終了日
	 * @param {string} period - 期間タイプ
	 * @param {string} aggregationType - 集計方法
	 * @param {string} graphType - グラフの種類
	 * @returns {string} iframe用URL
	 */
	function getIframeSrcGraph(start, end, period, aggregationType, graphType) {
		const timestamp = new Date().getTime();
		return `/settings/dashboard/graph/?dayStart=${start}&dayEnd=${end}&periodType=${period}&aggregationType=${aggregationType}&graphType=${graphType}&t=${timestamp}`;
	}

	/**
	 * OKボタンクリック時の処理
	 *        iframe URLを更新し、イベントを読み込み、カレンダーを更新
	 * @async
	 */
	async function handleButtonClick() {
		const url = getIframeSrcGraph(
			selectedFrom,
			selectedTo,
			getPeriodType(selectedTypePeriod),
			getAggregationType(selectedTypeAggregation),
			getGraphType(selectedGraph)
		);
		iframeSrcGraph = url;

		showGraph = true;
		iframeSrcInformation = `/settings/dashboard/information?date=${selectedFrom}`;

		await loadEvents();

		const [y, m] = selectedFrom.split('-');
		const target = new Date(Number(y), Number(m), 1);
		calendarComponent.goto(target);
	}


	/**
	 * OKボタンクリック時の処理
	 *        iframe URLを更新し、イベントを読み込み、カレンダーを更新
	 * @async
	 */
	async function handleButtonCalendarEventDayClick(selectedDay) {
		
		getAggregationType(selectedTypeAggregation),
		getGraphType(selectedGraph)
		const url = getIframeSrcGraph(
			selectedDay,
			selectedDay,
			getPeriodType('時間別'),
			getAggregationType(selectedTypeAggregation),
			getGraphType(selectedGraph)
		);
		iframeSrcGraph = url;
	}

	/**
	 * APIからイベントデータを取得し、eventsに格納
	 * @async
	 */
	async function loadEvents() {
		const res = await fetch(`?month=${selectedFrom}`);
		if (!res.ok) {
			console.error('データ取得エラー', await res.text());
			return;
		}
		const data = await res.json();
		events = data.events;
	}

	$: if (clickedEvent) {
		//alert('データあります');
		// if ($clickedEvent.enabled) {
		// }
	}

	$: if ($clickedEvent.enabled) {
		// clickedEvent.date を selectedFrom に反映（必要なら）

		// グラフ表示などの処理を実行
		handleButtonCalendarEventDayClick($clickedEvent.date);

		// 一度だけ実行するためにフラグを戻す
		clickedEvent.set({ enabled: false, date: $clickedEvent.date });
	}
</script>

<div class="container">
	<!-- =========================================
     左側のメニュー領域（設定パネル）
  ========================================= -->
	<div class="common-left-menu">
		<!-- メニュータイトル -->
		<div class="common-menu-title">設定</div>

		<!-- 表示期間選択 -->
		<div class="common-menu-item">
			<div class="common-menu-item-name">表示期間</div>
			<label class="common-menu-dropdown">
				<select bind:value={selectedTypePeriod}>
					{#each CONSTANTS.TYPES_PERIOD as option}
						<option value={option.label}>{option.label}</option>
					{/each}
				</select>
			</label>
		</div>

		<!-- 日付指定 -->
		<div class="common-menu-item">
			<div class="common-menu-item-name">日付指定</div>
			<input type="date" class="common-menu-date" bind:value={selectedFrom} />

			<!-- from-toアイコン -->
			<div class="menu-icon-from-to-row">
				<img src={'/up-down-arrows.svg'} class="menu-icon-from-to" alt="" />
			</div>
			<input type="date" class="common-menu-date" bind:value={selectedTo} />
			<div class="menu-dotted-line"></div>
		</div>

		<!-- グラフタイプ選択ボタン -->
		<div class="common-menu-item">
			<div class="button-graph-group">
				{#each graphTypes as graph}
					<button
						class="button-graph-select {selectedGraph === graph.index
							? 'selected'
							: ''} {graph.index === 0 ? 'left' : ''} {graph.index === 1
							? 'middle'
							: ''} {graph.index === 2 ? 'right' : ''}"
						on:click={() => (selectedGraph = graph.index)}
					>
						<img src={graph.icon} class="button-graph-icon" alt="" />
					</button>
				{/each}
			</div>
		</div>

		<!-- 階層選択と集計単位 -->
		<div class="menu-inner-first-container">
			<div class="menu-inner-title">階層選択</div>
			<div class="menu-inner-dotted-line"></div>

			<!-- 各階層のドロップダウン -->
			{#each menuHierarchyItems as itemData, index}
				<div class="menu-inner-title">{itemData.name}</div>
				<label class="common-menu-inner-dropdown">
					<select bind:value={selectedHierarchyItems[index]}>
						{#each itemData.listItem as item}
							<option value={item}>{item}</option>
						{/each}
					</select>
				</label>
			{/each}

			<!-- 集計単位選択 -->
			<div class="menu-inner-title">集計単位</div>
			<div class="menu-inner-dotted-line"></div>
			<label class="common-menu-inner-dropdown-simple">
				<select bind:value={selectedTypeAggregation}>
					{#each CONSTANTS.TYPES_AGG as option}
						<option value={option.label}>{option.label}</option>
					{/each}
				</select>
			</label>

			<!-- OKボタン -->
			<div class="menu-content">
				<button class="button-first" on:click={handleButtonClick}>OK</button>
			</div>
		</div>
	</div>

	<!-- =========================================
     右側のメイン表示領域
  ========================================= -->
	<div class="main-container-all">
		<!-- ヘッダー -->
		<div class="header-area">
			<div class="header-title">日別 / 全体</div>
		</div>

		<!-- ヘッダー下のバー -->
		<div class="header-bar-area">
			<div class="header-bar"></div>
		</div>

		<!-- 情報表示用iframe -->
		<div class="grid-item-information">
			<iframe src={iframeSrcInformation} class="info-frame" title="情報"></iframe>
		</div>

		<!-- カレンダー表示 -->
		<div class="grid-item-calendar">
			<div class="grid-item-Calender-title-boxes">
				<div class="grid-item-Calender-title">カレンダー表示</div>
				<div class="grid-item-Calender-subtitle">
					<span class="font-mark">● </span>
					<span class="font-label">単位は</span>
					<span class="font-unit">kWh</span>
					<span class="font-note">で表示</span>
				</div>
			</div>

			<!-- カレンダーのレイアウト（左右スペース付き） -->
			<div class="calendar-layout">
				<div class="calendar-side-space left"></div>
				<div class="calendar-main">
					<FullCalendar bind:this={calendarComponent} {events} />
				</div>
			</div>
		</div>

		<!-- グラフ表示用iframe -->
		<div class="grid-item-graph">
			{#if showGraph}
				<iframe src={iframeSrcGraph} class="graph-frame" title="グラフ1"></iframe>
			{/if}
		</div>
	</div>
</div>

<style>
	/* 全体の余白とスクロール設定をリセット */
	:global(html),
	:global(body) {
		margin: 0;
		padding: 0;
		height: 100%;
		overflow: hidden;
		font-size: 16px;
	}

	/* 全体コンテナのレイアウト */
	.container {
		display: flex;
		height: 100vh;
		overflow: hidden;
	}

	/* メイン表示領域のグリッドレイアウト */
	.main-container-all {
		display: grid;
		grid-template-columns: 1fr 1fr 1fr 1fr;
		grid-template-rows: 7% 40% 50%;
		gap: 10px;
		flex-grow: 1;
	}

	/* メニュー内のコンテンツ領域 */
	.menu-content {
		padding: 16px;
		display: flex;
		flex-direction: column;
		gap: 10px;
		margin-right: -5px;
	}

	/* 階層選択などのメニューブロック */
	.menu-inner-first-container {
		padding: 10px;
		background-color: #fcfefe;
		border-radius: 8px;
		margin: 10px;
	}

	/* メニュー項目のタイトル */
	.menu-inner-title {
		color: #009999;
		font-size: 1em;
		font-weight: bold;
		margin: 3px 3px 0 0;
	}

	/* メニュー内の区切り線 */
	.menu-inner-dotted-line {
		border-bottom: 2px solid #099999;
		width: 100%;
		margin: 8px 0 0 0;
	}

	/* OKボタンのスタイル */
	.button-first {
		width: 40%;
		padding: 8px 16px;
		background-color: #009999;
		color: white;
		border: none;
		cursor: pointer;
		align-self: flex-end;
		border-radius: 4px;
	}

	/* iframeの基本スタイル（情報・グラフ） */
	.info-frame,
	.graph-frame {
		width: 100%;
		border: none;
	}

	/* iframeのスタイル */
	iframe {
		width: 100%;
		height: 100%;
		border: none;
		display: block;
	}

	/* ヘッダーのタイトル表示 */
	.header-title {
		background-color: #009999;
		color: #ffffff;
		padding: 3px;
		padding-left: 20px;
		margin-left: 10px;
		display: inline-block;
		font-weight: bold;
		font-size: 1.6em;
		border-radius: 9999px;
		width: 100%;
	}

	/* ヘッダー領域のスタイル */
	.header-area {
		grid-column: span 3;
		background-color: white;
	}

	/* ヘッダー下のバー領域 */
	.header-bar-area {
		grid-column: span 1;
		align-content: center;
		padding-left: 40px;
		padding-right: 20px;
	}

	/* ヘッダー下のバーのスタイル */
	.header-bar {
		height: 2px;
		background-color: #099999;
		align-items: center;
		border-radius: 9999px;
	}

	/* 情報表示領域 */
	.grid-item-information {
		grid-row: 2;
		grid-column: span 2;
		margin-left: 10px;
		background: #f2f2f2;
		justify-content: center;
		align-items: center;
	}

	/* カレンダー表示領域 */
	.grid-item-calendar {
		grid-row: 2;
		grid-column: span 2;
		margin-left: 10px;
	}

	/* カレンダーのタイトルと単位表示 */
	.grid-item-Calender-title-boxes {
		display: flex;
		gap: 10px;
		width: 100%;
		background-color: #f5f5f5;
		padding: 8px 8px;
	}

	/* カレンダーのメインタイトル */
	.grid-item-Calender-title {
		font-size: 1.2em;
		font-weight: bold;
		background-color: #f2f2f2;
		white-space: nowrap;
	}

	/* カレンダーのサブタイトル（単位など） */
	.grid-item-Calender-subtitle {
		display: flex;
		gap: 5px;
		font-size: 1em;
		align-items: center;
		white-space: nowrap;
		margin-left: auto;
		margin-right: 20px;
	}

	/* 単位マークの色 */
	.font-mark {
		color: #099999;
	}

	/* 単位ラベルと補足の色 */
	.font-label,
	.font-note {
		color: black;
	}

	/* 単位の強調表示 */
	.font-unit {
		color: #099999;
		font-weight: bold;
		font-size: 1.2em;
	}

	/* カレンダーのレイアウト（左右スペース付き） */
	.calendar-layout {
		display: flex;
		width: 100%;
		height: auto;
	}

	/* カレンダー左側の余白 */
	.calendar-side-space.left {
		flex-basis: 10%;
		min-width: 3px;
		max-width: 10px;
		background-color: #f5f5f5;
	}

	/* カレンダー本体 */
	.calendar-main {
		flex: 1;
		min-width: 0;
	}

	/* グラフ表示領域 */
	.grid-item-graph {
		grid-row: 3;
		grid-column: span 4;
	}

	/* from-toアイコンの行 */
	.menu-icon-from-to-row {
		text-align: center;
		margin: 4px 0 2px 0;
	}

	/* from-toアイコンのサイズ */
	.menu-icon-from-to {
		width: 24px;
		height: 24px;
	}

	/* メニュー内の点線区切り */
	.menu-dotted-line {
		border-bottom: 1px dashed #999;
		width: 100%;
		margin: 16px 0 0 0;
	}

	/* グラフタイプ選択ボタンのグループ */
	.button-graph-group {
		display: flex;
		gap: 0;
	}

	/* グラフタイプ選択ボタンの基本スタイル */
	.button-graph-select {
		padding: 3px 20px;
		border: 1px solid white;
		background-color: #008080;
		color: white;
		font-size: 16px;
		cursor: pointer;
		transition: background-color 0.3s;
		border-radius: 0;
		width: 33%;
	}

	/* 選択中のグラフボタンのスタイル */
	.button-graph-select.selected {
		background-color: #ffd700;
		color: white;
	}

	/* グラフボタンの左端スタイル */
	.button-graph-select.left {
		border-radius: 10px 0 0 10px;
		border-color: 10px white;
	}

	/* グラフボタンの中央スタイル */
	.button-graph-select.middle {
		border-color: white;
	}

	/* グラフボタンの右端スタイル */
	.button-graph-select.right {
		border-radius: 0 10px 10px 0;
		border-color: white;
	}

	/* グラフボタン内のアイコンサイズ */
	.button-graph-icon {
		width: 32px;
		height: 32px;
	}
</style>
