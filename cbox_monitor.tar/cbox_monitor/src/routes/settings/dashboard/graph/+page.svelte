<script>
	import { onMount } from 'svelte';
	import { Chart, registerables } from 'chart.js';
	import 'chartjs-adapter-luxon';
	import { adjustCanvasResolution } from '$lib/utils/chartUtils';
	import { CONSTANTS } from '$lib/constants';
	import { DateTime } from 'luxon';

	Chart.register(...registerables);

	/**
	 * @typedef {Object} GraphData
	 * @property {string} date - 日付
	 * @property {number} total - 合計電力
	 * @property {number} electricpower - 電力使用量
	 */

	/**
	 * @typedef {Object} ChartProps
	 * @property {GraphData[]} graphData - グラフ表示用のデータ配列
	 * @property {string} start - 開始日
	 * @property {string} end - 終了日
	 * @property {string} period - 集計期間タイプ
	 * @property {string} aggregationType - 集計方法（例：grouped, stacked）
	 * @property {string} graphType - グラフの種類（例：bar, line）
	 * @property {string} dataType - データの形式（single or multiple）
	 */

	/** @type {ChartProps} */
	export let data;

	/**
	 * グラフ描画に使用するCanvas要素
	 * @type {import("chart.js").ChartItem}
	 */
	let chartCanvas;

	/**
	 * コンポーネントのマウント時にChart.jsグラフを初期化する。
	 * データの形式に応じて、単一または複数のデータセットを生成。
	 */
	onMount(() => {
		// データ形式の確認
		if (!Array.isArray(data.graphData)) {
			console.error('graphData is not an array:', data);
			return;
		}

		/** @type {import("chart.js").ChartDataset[]} */
		const datasets = [];

		// 単一データ形式の場合（合計のみ表示）
		if (data.dataType === 'single') {
			datasets.push({
				label: '合計',
				data: data.graphData.map((d) => d.total),
				backgroundColor: 'rgba(9, 153, 153, 0.9)',
				stack: data.aggregationType === 'stacked' ? 'stack1' : undefined
			});
		} else {
			// 複数データ形式の場合（電力、塗装ライン、組立ラインなど）
			datasets.push({
				label: '電力',
				data: data.graphData.map((d) => d.electricpower),
				backgroundColor: 'rgba(9, 153, 153, 0.9)',
				stack: data.aggregationType === 'stacked' ? 'stack1' : undefined
			});
			// datasets.push({
			//       label: "塗装ライン",
			//       data: data.graphData.map((d) => d.painting),
			//       backgroundColor: "rgba(255, 192, 0, 0.9)",
			//       stack: data.aggregationType === "stacked" ? "stack1" : undefined,
			// });
			// datasets.push({
			//       label: "組立ライン",
			//       data: data.graphData.map((d) => d.assembly),
			//       backgroundColor: "rgba(0, 176, 240, 0.9)",
			//       stack: data.aggregationType === "stacked" ? "stack1" : undefined,
			// });
		}

		// X軸の単位と表示形式を period に応じて設定
		let timeUnit = 'day';
		let displayFormat = 'MM/dd';

		switch (data.period) {
			case 'minutely':
				timeUnit = 'second';
				displayFormat = 'HH:mm:ss';
				break;
			case 'hourly':
				timeUnit = 'hour';
				displayFormat = 'HH:mm';
				break;
			case 'daily':
				timeUnit = 'day';
				displayFormat = 'MM/dd';
				break;
			case 'monthly':
				timeUnit = 'month';
				displayFormat = 'yyyy/MM';
				break;
		}

		// Canvasの解像度を調整（高DPI対応）
		adjustCanvasResolution(chartCanvas);

		// 表示ラベルの取得（期間タイプに応じて）
		const periodLabel =
			CONSTANTS.TYPES_PERIOD.find((t) => t.key === data.period)?.label ??
			CONSTANTS.TYPES_PERIOD[1].label;

		// Chart.jsのインスタンス生成
		const chart = new Chart(chartCanvas, {
			type: data.graphType,
			data: {
				labels: data.graphData.map((d) => d.date),
				datasets
			},
			options: {
				responsive: true,
				scales: {
					x: {
						stacked: data.aggregationType === 'stacked',
						type: 'time',
						time: {
							unit: timeUnit,
							displayFormats: {
								[timeUnit]: displayFormat
							},
							tooltipFormat:
								CONSTANTS.TYPES_PERIOD.find((t) => t.key === data.period)?.tooltipFormat ??
								CONSTANTS.TYPES_PERIOD[1].tooltipFormat
						},
						ticks:
							timeUnit === 'day'
								? {
										callback: function (value) {
											const dt = DateTime.fromMillis(value).setLocale('ja');
											return dt.toFormat('MM/dd(EEE)');
										}
									}
								: {}
					},
					y: {
						stacked: data.aggregationType === 'stacked',
						ticks: {
							// 縦軸 単位表示
							callback: function (value, index, ticks) {
								return index < ticks.length - 1
									? this.getLabelForValue(value)
									: ['[kWh]', this.getLabelForValue(value)];
							}
						}
					}
				},
				plugins: {
					title: {
						display: true,
						position: 'top',
						text: `${periodLabel}グラフ（電力使用量）`,
						color: '#099999',
						font: {
							size: 24,
							family: 'Yu Gothic UI',
							weight: 'bold'
						}
					},
					legend: {
						position: 'right',
						labels: {
							boxHeight: 16,
							boxWidth: 16
						}
					}
				}
			}
		});

		// コンポーネントのアンマウント時にChartインスタンスを破棄
		return () => chart.destroy();
	});
</script>

<!-- グラフ描画 -->
<div class="chart-wrapper">
	<canvas bind:this={chartCanvas}></canvas>
</div>

<style>
	/* 全体の余白とスクロール設定をリセット */
	:global(html),
	:global(body) {
		margin: 0;
		padding: 0 0 0 2%;
		height: 100%;
		overflow: hidden;
	}

	.chart-wrapper {
		width: 100%;
		height: 100vh;
		box-sizing: border-box;
	}

	/* グラフ要素のレイアウト */
	canvas {
		width: 100% !important;
		height: 100% !important;
		display: block;
	}
</style>
