import dotenv from 'dotenv';

/**
 * 環境変数を.envファイルから読み込む。
 *
 * @function
 * @description データベース接続情報（ホスト、ポート、ユーザー名など）を環境変数から取得するために使用。
 */
dotenv.config();
