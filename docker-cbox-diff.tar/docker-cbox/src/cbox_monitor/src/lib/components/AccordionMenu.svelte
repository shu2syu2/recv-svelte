<!-- 
  @file AccordionMenu.svelte 
  @description アコーディオンメニューを表示するSvelteコンポーネント
  @author FSI 
  @date 2025-06-12
-->

<script>
	/**
	 * メニュー項目のデータオブジェクト
	 * @type {{
	 *   name: string,
	 *   nameTag: string,
	 *   nameIconOpen: string,
	 *   nameIconClose: string,
	 *   subMenu: string[],
	 *   subMenuPage: string[]
	 * }}
	 */
	export let menuItem;

	/**
	 * メニューが開いているかどうかのフラグ
	 * @type {boolean}
	 */
	export let isOpen;

	/**
	 * メニューの開閉を切り替える関数
	 * @param {string} nameTag - メニューのタグ名
	 * @returns {void}
	 */
	export let toggleMenu;

	/**
	 * iframeの表示先を設定する関数
	 * @param {string} page - 表示するページのURL
	 * @param {string} menuTag - メニューのタグ名
	 * @param {string} subItem - サブメニュー名
	 * @returns {void}
	 */
	export let setIframeSrc;

	/**
	 * 現在選択されているサブメニュー情報
	 * @type {{ menuTag: string, subItem: string }}
	 */
	export let selectedSubItem;
</script>


{#if isOpen}
	<!-- メニューが開いているとき -->
	<h3>
		<div class="menu-accordion-open">
			<div class="circleparts-open">
				<img src={menuItem.nameIconOpen} alt="" />
			</div>
			<button class="stickparts-open" on:click={() => toggleMenu(menuItem.nameTag)}>
				{menuItem.name}
			</button>
		</div>
	</h3>
	<ul class="submenu-accordion">
		{#each menuItem.subMenu as subItem, index}
			<li
				class={selectedSubItem.menuTag === menuItem.nameTag && selectedSubItem.subItem === subItem
					? 'active'
					: ''}
			>
				<button
					on:click={() => setIframeSrc(menuItem.subMenuPage[index], menuItem.nameTag, subItem)}
				>
					{subItem}
				</button>
			</li>
		{/each}
	</ul>
{:else}
	<!-- メニューが閉じているとき -->
	<h3>
		<div class="menu-accordion-close">
			<div class="circleparts-close">
				<img src={menuItem.nameIconClose} alt="" />
			</div>
			<button class="stickparts-close" on:click={() => toggleMenu(menuItem.nameTag)}>
				{menuItem.name}
			</button>
		</div>
	</h3>
{/if}

<style>
	/* 全体の余白とスクロール設定をリセット */
	:global(html),
	:global(body) {
		margin: 0;
		padding: 0;
		height: 100%;
		overflow: hidden;
	}

	/* メニューの開閉状態の共通スタイル */
	.menu-accordion-open,
	.menu-accordion-close {
		display: flex;
		align-items: center;
		margin: 15px 0;
	}

	/* 丸いアイコン部分（開閉共通） */
	.circleparts-open,
	.circleparts-close {
		width: 42px;
		height: 42px;
		background-color: white;
		border: 5px solid;
		border-radius: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
		position: relative;
		z-index: 2;
	}

	/* 丸いアイコン内の画像サイズ */
	.circleparts-open img,
	.circleparts-close img {
		width: 25px;
		height: 25px;
	}

	/* 開いているときの丸枠の色 */
	.circleparts-open {
		border-color: #009999;
	}

	/* 閉じているときの丸枠の色 */
	.circleparts-close {
		border-color: #7f7f7f;
	}

	/* 棒状のボタン部分（開閉共通） */
	.stickparts-open,
	.stickparts-close {
		width: 200px;
		height: 40px;
		display: flex;
		justify-content: center;
		align-items: center;
		color: white;
		font-size: 18px;
		position: relative;
		margin-left: -30px;
		border-radius: 0 20px 20px 0;
		z-index: 1;
		border: 3px solid;
	}

	/* 開いているときのボタン背景色 */
	.stickparts-open {
		background-color: #009999;
	}

	/* 閉じているときのボタン背景色 */
	.stickparts-close {
		background-color: #7f7f7f;
	}

	/* ボタン右端の矢印アイコン */
	.stickparts-open::after,
	.stickparts-close::after {
		content: '▼';
		position: absolute;
		right: 10px;
	}

	/* サブメニューリスト全体のスタイル */
	.submenu-accordion {
		margin: 0;
		padding: 10px;
		list-style: none;
		margin-bottom: 120px;
	}

	/* サブメニューのボタンスタイル */
	.submenu-accordion button {
		width: 100%;
		text-align: left;
		padding: 10px;
		color: #948a54;
		font-size: 1em;
		font-weight: bold;
		background-color: white;
		border: none;
		border-bottom: 2px solid #d9d9d9;
		cursor: pointer;
	}

	/* 選択中のサブメニューのスタイル */
	.submenu-accordion li.active button {
		background-color: #e0e0e0;
		color: #000;
	}
</style>
