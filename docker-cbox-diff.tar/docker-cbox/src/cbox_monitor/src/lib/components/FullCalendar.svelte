<!--
  @file Calendar.svelte
  @description カレンダー画面構成（FullCalendarを使用）
  @author FSI
  @date 2025/06/12
-->

<script>
	import { onMount } from 'svelte';
	import FullCalendar from 'svelte-fullcalendar';
	import interactionPlugin from '@fullcalendar/interaction';
	import dayGridPlugin from '@fullcalendar/daygrid';
	import '@fullcalendar/common/main.css';
	import { clickedEvent } from '$lib/stores/calencarStore';
	/**
	 * 表示するイベントの配列
	 * @type {Array<Object>}
	 */
	export let events = [];

	/**
	 * FullCalendarのDOM参照
	 * @type {import("svelte").SvelteComponent}
	 */
	let calendar;

	/**
	 * FullCalendarのAPIインスタンス
	 * @type {import("svelte-fullcalendar").Calendar}
	 */
	let calendarApi;

	/**
	 * 他月の表示を記録するセット
	 * @type {Set<number>}
	 */
	let seenOtherMonths = new Set();

	/**
	 * カレンダーの表示範囲が変更されたときに呼ばれる
	 *        他月の表示記録をリセットする
	 */
	function handleDatesSet() {
		seenOtherMonths.clear();
	}

	/**
	 * FullCalendarの基本オプション設定
	 * @type {import("svelte-fullcalendar").CalendarOptions}
	 */
	const baseOptions = {
		plugins: [dayGridPlugin, interactionPlugin],
		droppable: true,
		editable: true,
		selectable: true,
		selectMirror: true,
		fixedWeekCount: true,
		themeSystem: 'standard',
		initialView: 'dayGridMonth',
		headerToolbar: false,
		locale: 'ja',
		timeZone: 'Asia/Tokyo',
		height: 'auto',
		datesSet: handleDatesSet,
		/**
		 * 各日付セルの表示内容をカスタマイズ
		 * @param {Object} param
		 * @param {Date} param.date - 日付
		 * @param {boolean} param.isOther - 他月かどうか
		 * @returns {{ html: string }} HTML表示内容
		 */
		dayCellContent: ({ date, isOther }) => {
			const m = date.getMonth() + 1;
			const d = date.getDate();
			if (!isOther && d === 1) {
				return { html: `${m}/${d}` };
			}
			if (isOther) {
				if (!seenOtherMonths.has(m)) {
					seenOtherMonths.add(m);
					return { html: `${m}/${d}` };
				}
				return { html: `${d}` };
			}
			return { html: `${d}` };
		},

		/**
		 * FullCalendarのイベントクリック時のハンドラ。
		 * タイトルと日付をストアに保存する。
		 *
		 * @param {Object} info - FullCalendarから渡されるイベント情報オブジェクト
		 * @param {Object} info.event - クリックされたイベントの情報
		 */
		eventClick: (info) => {
			const title = info.event.title;
			const dateStr = info.event.startStr;

			if (title) {
				clickedEvent.set({ enabled: true, date: dateStr });
			}

			// 選択状態のクラスを手動で追加
			const date = new Date(dateStr);
			const y = date.getFullYear();
			const m = String(date.getMonth() + 1).padStart(2, '0');
			const d = String(date.getDate()).padStart(2, '0');
			const selector = `.fc-day[data-date="${y}-${m}-${d}"]`;

			// 既存の選択をクリア
			document.querySelectorAll('.fc-day.selected').forEach((el) => {
				el.classList.remove('selected');
			});

			// 新しい選択を追加
			const cell = document.querySelector(selector);
			if (cell) {
				cell.classList.add('selected');
			}
		},

		/**
		 * FullCalendarの日付セルがクリックされたときに呼び出されるハンドラ。
		 *
		 * - クリックされた日付にイベントが存在しない場合、選択状態を解除し、
		 *   `clickedEvent` ストアをリセットする。
		 * - イベントが存在する場合は何もしない（`eventClick` が処理を担当）。
		 *
		 * @param {Object} info - FullCalendarから渡されるクリック情報オブジェクト
		 * @param {Date} info.date - クリックされた日付のDateオブジェクト
		 * @param {string} info.dateStr - ISO形式のクリックされた日付文字列（例: "2025-06-16"）
		 */
		dateClick: (info) => {
			const dateStr = info.dateStr;

			// クリックされた日付にイベントがあるか確認
			const hasEvent = events.some((e) => {
				const eventDate = typeof e.start === 'string' ? e.start.split('T')[0] : '';
				return eventDate === dateStr;
			});

			// イベントがない場合、選択状態をクリア
			if (!hasEvent) {
				clickedEvent.set({ enabled: false, date: null });

				document.querySelectorAll('.fc-day.selected').forEach((el) => {
					el.classList.remove('selected');
				});
			}
		}
	};

	/**
	 * eventsが更新されたときにカレンダーに反映
	 */
	$: if (calendarApi) {
		calendarApi.removeAllEventSources();
		calendarApi.addEventSource(events);
	}

	/**
	 * コンポーネントマウント時にAPIを取得
	 */
	onMount(() => {
		calendarApi = calendar.getAPI();
	});

	/**
	 * 指定した日付にカレンダーを移動
	 * @param {string|Date} date - 移動先の日付
	 */
	export function goto(date) {
		if (!calendarApi) return;
		calendarApi.changeView('dayGridMonth', date);
	}
</script>

<!--
  @component Calendar
  @description FullCalendarコンポーネントを表示するカレンダーUI。
-->
<div class="Calendar">
	<FullCalendar options={baseOptions} bind:this={calendar} />
</div>

<style>
	:global(body) {
		overflow: hidden;
	}

	.Calendar {
		width: 100%;
		height: 100%;
		overflow: hidden;
	}

	/* フルカレンダーのレスポンシブ対応 */
	:global(.fc) {
		width: 100% !important;
		height: 100% !important;
		font-size: calc(0.6em + 0.4vw);
	}

	/* ヘッダー */
	:global(.fc .fc-col-header-cell) {
		background-color: #099999;
		height: 4vh;
		padding: 0;
		vertical-align: middle;
		border-width: 2px;
		border-bottom-width: 0px;
	}
	:global(.fc .fc-col-header-cell-cushion) {
		color: white;
		display: flex;
		justify-content: center;
		align-items: center;
		height: 100%;
		font-size: 1.5em;
		font-weight: normal;
	}

	/* 丸める */
	:global(.fc .fc-col-header-cell:first-child) {
		border-top-left-radius: 0.5rem;
		overflow: hidden;
	}
	:global(.fc .fc-col-header-cell:last-child) {
		border-top-right-radius: 0.5rem;
		overflow: hidden;
	}

	/* 日付セルの高さを調整 */
	:global(.fc .fc-daygrid-day-frame),
	:global(.fc .fc-daygrid-day) {
		height: 45px; /* 日付セルの高さを設定 */
		overflow: hidden;
	}

	/* 日付番号を左上に移動 */
	:global(.fc .fc-daygrid-day-top) {
		position: relative;
		z-index: 2;
	}

	/* イベントの表示領域を調整 */
	:global(.fc .fc-daygrid-day-events) {
		margin-top: 15px;
		margin-left: 25px;
	}

	:global(.fc .fc-daygrid-day-number) {
		position: absolute;
		top: 2px;
		left: 0;
		right: 0;
		text-align: left;
		padding: 0;
		font-size: 0.8em;
		font-weight: normal;
		color: #333;
	}

	/* セル内のパディングを調整 */
	:global(.fc .fc-daygrid-day-frame) {
		padding: 2px;
	}

	/* 日付部の線色だけを上書き */
	:global(.fc .fc-scrollgrid-section-body td) {
		border-color: #099999;
		border-width: 2px;
	}

	/* スクロールやレイアウト崩れを防ぐためにオーバーフローを調整 */
	:global(.fc-scroller-harness, .fc-scroller-harness-liquid) {
		overflow: hidden;
	}

	/* メディアクエリを使用してフォントサイズを調整 */
	@media screen and (max-width: 768px) {
		:global(.fc) {
			font-size: 0.8em;
		}
		:global(.fc .fc-col-header-cell-cushion) {
			font-size: 1em; /* 小さい画面でのヘッダーフォントサイズ */
		}
		:global(.fc .fc-daygrid-day-number) {
			font-size: 0.8em; /* 小さい画面での日付番号フォントサイズ */
		}
	}

	/* 当日に色を付けない */
	:global(.fc .fc-day-today) {
		background-color: transparent !important;
		color: inherit !important;
	}

	/* イベント本体の枠線を消す */
	:global(.fc .fc-daygrid-event) {
		background-color: inherit !important;
		border: none !important;
	}

	/* イベント内部フレームの枠線も消す */
	:global(.fc .fc-event-main-frame) {
		background-color: inherit !important;
		border: none !important;
	}

	/* イベントタイトル／時間は黒文字のまま */
	:global(.fc .fc-event-title),
	:global(.fc .fc-event-time) {
		color: #000 !important;
	}

	/* イベント ホバーアイコンは変えない */
	:global(.fc .fc-daygrid-day-frame),
	:global(.fc .fc-daygrid-day-frame:hover),
	:global(.fc .fc-daygrid-event),
	:global(.fc .fc-daygrid-event:hover),
	:global(.fc .fc-event-main-frame),
	:global(.fc .fc-event-main-frame:hover) {
		cursor: default !important;
	}

	/* 日付選択状態の背景色（イベントがある日にもつける） */
	:global(.fc .fc-day.selected) {
		background-color: rgba(0, 153, 153, 0.1);
	}
</style>
