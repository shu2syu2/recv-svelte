<script>
	import { onMount, tick } from 'svelte';
	import { Chart, registerables } from 'chart.js';
	import 'chartjs-adapter-luxon';
	import { adjustCanvasResolution } from '$lib/utils/chartUtils.js';

	// Chart.jsのプラグインを登録
	Chart.register(...registerables);

	/**
	 * 表示するデータオブジェクト
	 * @type {{
	 *   title: string,
	 *   frequencyRows: Array<{ reg_date: string, ave_value: number }>,
	 *   thresholdRow: {
	 *     warn_upper: number,
	 *     fatal_lower: number,
	 *     fatal_upper: number
	 *   }
	 * }}
	 */
	export let data;

	/**
	 * チャートを描画するCanvas要素
	 * @type {import("chart.js").ChartItem}
	 */
	let chartCanvas;

	/**
	 * Chart.jsのインスタンス
	 * @type {Chart}
	 */
	let chart;

	/**
	 * コンポーネントマウント時にチャートを初期化
	 * @async
	 */
	onMount(async () => {
		await tick();
		if (!data.frequencyRows.length) return;

		const labels = data.frequencyRows.map((p) => p.reg_date);

		/** @type {import("chart.js").ChartDataset[]} */
		const datasets = [
			{
				label: data.title,
				data: data.frequencyRows.map((p) => p.ave_value),
				borderColor: 'rgba(79, 129, 189, 1)',
				backgroundColor: 'rgba(79, 129, 189, 0.2)',
				fill: false,
				tension: 0.1,
				pointRadius: 0
			}
		];

		// 注意ライン
		if (data.thresholdRow.warn_upper !== -1) {
			datasets.push({
				label: '注意ライン',
				data: Array(labels.length).fill(data.thresholdRow.warn_upper),
				borderColor: 'rgba(255, 240, 174, 1)',
				backgroundColor: 'rgba(255, 240, 174, 0.1)',
				fill: false,
				tension: 0.1,
				pointRadius: 0
			});
		}

		// 警告ライン
		if (data.thresholdRow.fatal_lower !== -1) {
			datasets.push({
				label: '警告ライン',
				data: Array(labels.length).fill(data.thresholdRow.fatal_lower),
				borderColor: 'rgba(255, 187, 146, 1)',
				backgroundColor: 'rgba(255, 187, 146, 0.1)',
				fill: false,
				tension: 0.1,
				pointRadius: 0
			});
		}

		// 危険ライン
		if (data.thresholdRow.fatal_upper !== -1) {
			datasets.push({
				label: '危険ライン',
				data: Array(labels.length).fill(data.thresholdRow.fatal_upper),
				borderColor: 'rgba(255, 127, 127, 1)',
				backgroundColor: 'rgba(255, 127, 127, 0.1)',
				fill: false,
				tension: 0.1,
				pointRadius: 0
			});
		}

		// 解像度調整
		adjustCanvasResolution(chartCanvas);

		// チャートの初期化
		chart = new Chart(chartCanvas, {
			type: 'line',
			data: {
				labels,
				datasets
			},
			options: {
				maintainAspectRatio: false,
				scales: {
					x: {
						type: 'time',
						time: {
							unit: 'day',
							displayFormats: {
								day: 'yyyy-MM-dd'
							},
							tooltipFormat: 'yyyy-MM-dd HH:mm:ss'
						}
					},
					y: {
						beginAtZero: true
					}
				},
				plugins: {
					legend: {
						position: 'bottom'
					}
				}
			}
		});
	});
</script>

<!--
  @component ChartWrapper
  @description Chart.js を使用して折れ線グラフを描画するラッパーコンポーネント。
  @binds chartCanvas - JavaScript側で参照される <canvas> 要素。
-->
<div class="chart-wrapper">
	<canvas bind:this={chartCanvas}></canvas>
</div>

<style>
	/* 全体の余白とスクロール設定をリセット */
	:global(html),
	:global(body) {
		margin: 0;
		padding: 0;
		height: 100%;
		overflow: hidden;
	}

	/* チャート全体のレイアウト */
	.chart-wrapper {
		max-width: 100%;
		height: 95%;
		overflow-x: auto;
		border: 2px solid #00b050;
	}

	/* グラフ要素のレイアウト */
	canvas {
		width: 100% !important;
		height: 100% !important;
		display: block;
	}
</style>
