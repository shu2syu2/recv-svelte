<script>
  import '$lib/stores/sensorStore.js'; // ストアを初期化するだけ
</script>

<slot />
