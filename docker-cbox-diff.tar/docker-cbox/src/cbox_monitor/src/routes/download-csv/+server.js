import { pool } from '$lib/db.js';
import { SENSOR_NAMES } from '$lib/constants.js';
import Papa from 'papaparse';

/**
 * 指定されたテーブルと日付範囲に基づいてデータを取得し、CSV形式で返却する。
 *
 * @async
 * @function POST
 * @param {RequestEvent} request - SvelteKitのリクエストオブジェクト
 * @returns {Promise<Response>} CSVファイルまたはエラーメッセージを含むHTTPレスポンス
 */
export async function POST({ request }) {
	const formData = await request.formData();

	// フォームデータからパラメータを取得
	const table = formData.get('tableName');
	const column = formData.get('columnName');
	const start = formData.get('condFrom');
	const end = formData.get('condTo');

	const allowedColumns = SENSOR_NAMES.filter((sensor) => sensor.use).map((sensor) => sensor.column)

	// カラム名の検証
	if (!allowedColumns.includes(column)) {
		console.error('無効なカラム名:', column);
		return new Response('無効なカラム名が指定されました。', { status: 400 });
	}

	// 日付条件の検証
	if (!start || !end) {
		console.error('日付の条件が無効です:', { start, end });
		return new Response('日付の条件が無効です。', { status: 400 });
	}

	// データベースからデータを取得
	let data;
	let query;
	try {
		query = `
				SELECT
					"親機id",
					"子機id",
					"センサid",
					"センサ名称",
					DATE("日時") AS reg_date,
					AVG(${column}) AS ave_value
				FROM
				    public.${table}
				WHERE 
					DATE("日時") BETWEEN $1 AND $2
				AND
				    "${column}" IS NOT NULL
				GROUP BY
					"親機id", 
					"子機id", 
					"センサid", 
					"センサ名称", 
					DATE("日時")
				ORDER BY 
					reg_date;
		`;

		const result = await pool.query(query, [start, end]);
		console.log(`download sql= ${query} BETWEEN '${start}' AND '${end}'`);
		console.log(`download data count= ${result.rowCount}`);

		data = result.rows;
	} catch (error) {
		console.error('データベースエラー:', error);
		console.log(`download sql= ${query} BETWEEN '${start}' AND '${end}'`);
		return new Response('データベースエラーが発生しました。', { status: 500 });
	}

	// データが存在しない場合
	if (data.length === 0) {
		console.log('データが見つかりませんでした:', query);
		return new Response('指定された条件のデータが見つかりませんでした。', { status: 404 });
	}

	// CSV変換
	let csv;
	try {
		csv = Papa.unparse(data);
	} catch (error) {
		console.error('CSV変換エラー:', error);
		return new Response('CSV変換中にエラーが発生しました。', { status: 500 });
	}

	// UTF-8 BOM を付加
	const bom = '\uFEFF';
	const csvWithBom = bom + csv;

	// レスポンスヘッダー
	const headers = {
		'Content-Type': 'text/csv; charset=utf-8',
		'Content-Disposition': `attachment; filename="${table}_data.csv"`
	};
	// レスポンスとして返す
	return new Response(csvWithBom, {
		status: 200,
		headers
	});
}
