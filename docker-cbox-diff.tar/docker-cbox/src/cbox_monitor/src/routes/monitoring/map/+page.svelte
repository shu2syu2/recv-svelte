<script>
	/**
	 * @file MapComponent.svelte
	 * @description Leaflet.js を使用して地図を表示する Svelte コンポーネント
	 */

	import { onMount } from 'svelte';
	import L from 'leaflet';
	import 'leaflet/dist/leaflet.css';

	/**
	 * 地図インスタンス
	 * @type {L.Map}
	 */
	let map;

	/**
	 * コンポーネントがマウントされたときに地図を初期化する
	 *
	 * @function
	 * @description
	 * - 初期座標とズームレベルを設定
	 * - OpenStreetMap タイルレイヤを追加
	 * - カスタムアイコン付きのマーカーを表示
	 */
	onMount(() => {
		const initialCoords = [34.8351, 137.3704]; ///< 地図の初期中心座標
		const markerPoint = [34.8351, 137.3704]; ///< マーカーの表示位置
		const zoomLevel = 17; ///< ズームレベル（0〜18）

		// 地図を初期化し、指定した座標とズームで表示
		map = L.map('mapcontainer').setView(initialCoords, zoomLevel);

		// OpenStreetMap のタイルレイヤを追加
		L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
			attribution:
				'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
		}).addTo(map);

		// カスタムアイコンを作成
		const customIcon = L.icon({
			className: 'custom-icon',
			iconUrl: '/map-marker-running.svg',
			iconSize: [20, 20],
			iconAnchor: [10, 10]
		});

		// マーカーを追加し、ポップアップを表示
		L.marker(markerPoint, { icon: customIcon }).addTo(map).bindPopup('位置の説明').openPopup();
	});
</script>

<!--
@component MapComponent
@description Leaflet.js を使って地図を表示するコンポーネント。地図は #mapcontainer に描画される。
-->
<div id="mapcontainer"></div>

<style>
	/* 地図の表示領域のスタイル */
	#mapcontainer {
		width: 100%;
		height: 600px;
	}
</style>
