<script>
	import { getDateRange } from '$lib/utils/commonUtils.js';
	import { SENSOR_NAMES } from '$lib/constants.js';
	import { sensorData } from '$lib/stores/sensorStore.js';
	import { onDestroy } from 'svelte';
	import '$lib/styles/global.css';

	/**
	 * センサー名の選択肢（表示用）
	 * @type {string[]}
	 */
	let sensorNameOptions = SENSOR_NAMES.filter((sensor) => sensor.use).map(
		(sensor) => sensor.column
	);

	/**
	 * センサーキーの選択肢（内部処理用）
	 * @type {string[]}
	 */
	let sensorKeyOptions = SENSOR_NAMES.filter((sensor) => sensor.use).map((sensor) => sensor.key);

	/**
	 * 選択されたセンサー名（1つ目）
	 * @type {string}
	 */
	let selectedOption1 = sensorNameOptions[0];

	/**
	 * 選択されたセンサー名（2つ目）
	 * @type {string}
	 */
	let selectedOption2 = sensorNameOptions[1];

	/**
	 * グラフの表示状態
	 * @type {boolean}
	 */
	let showGraphs = true;

	/**
	 * センサー名から対応するキーを取得する
	 * @param {string} sensorName - センサー名（日本語）
	 * @returns {string|null} 対応するキー（英語）または null
	 */
	function getSensorKey(sensorName) {
		const index = sensorNameOptions.indexOf(sensorName);
		return index !== -1 ? sensorKeyOptions[index] : null;
	}

	/**
	 * グラフ表示用のiframeのURLを生成する
	 * @param {string} option - センサー名
	 * @returns {string} iframeのURL
	 */
	function getIframeSrcGraph(option) {
		return '/monitoring/sensors/graphs/' + getSensorKey(option);
	}

	/**
	 * 値表示用のiframeのURLを生成する
	 * @param {string} option - センサー名
	 * @returns {string} iframeのURL
	 */
	function getIframeSrcValue(option) {
		return `/monitoring/sensors/values/value1/?sensorName=${option}`;
	}

	let iframeSrcValue1 = getIframeSrcValue(selectedOption1);
	let iframeSrcValue2 = getIframeSrcValue(selectedOption2);
	/**
	 * iframeのURL（グラフ1）
	 * @type {string}
	 */
	let iframeSrcGraph1 = getIframeSrcGraph(selectedOption1);

	/**
	 * iframeのURL（グラフ2）
	 * @type {string}
	 */
	let iframeSrcGraph2 = getIframeSrcGraph(selectedOption2);

	/**
	 * OKボタンがクリックされたときの処理
	 * @returns {void}
	 */
	function handleButtonClick() {
		iframeSrcValue1 = getIframeSrcValue(selectedOption1);
		iframeSrcValue2 = getIframeSrcValue(selectedOption2);
		iframeSrcGraph1 = getIframeSrcGraph(selectedOption1);
		iframeSrcGraph2 = getIframeSrcGraph(selectedOption2);
	}

	/**
	 * グラフの表示/非表示を切り替える
	 * @returns {void}
	 */
	function toggleGraphs() {
		showGraphs = !showGraphs;
	}

	/**
	 * CSVファイルをダウンロードする
	 * @returns {void}
	 */
	function downloadCSV() {
		const tableName = 'data_table';
		const targetColums = [selectedOption1, selectedOption2];

		const range = getDateRange(30);
		const condFrom = range.start;
		const condTo = range.end;

		targetColums.forEach((column) => {
			const formData = new FormData();
			formData.append('tableName', tableName);
			formData.append('condFrom', condFrom);
			formData.append('condTo', condTo);
			formData.append('columnName', column);

			fetch('/download-csv', {
				method: 'POST',
				body: formData
			})
				.then((response) => {
					if (!response.ok) {
						return response.text().then((text) => {
							throw new Error(text);
						});
					}
					return response.blob();
				})
				.then((blob) => {
					const url = window.URL.createObjectURL(blob);
					const a = document.createElement('a');
					a.href = url;
					a.download = `${tableName}_data.csv`;
					document.body.appendChild(a);
					a.click();
					a.remove();
					window.URL.revokeObjectURL(url);
				})
				.catch((error) => {
					console.error('データのダウンロード中に問題が発生しました:', error);
					alert(`データのダウンロード中に問題が発生しました: ${error.message}`);
				});
		});
	}

	/**
	 * 通信状態
	 * @type {string}
	 */
	let connectCond = '-';

	/**
	 * RSSI
	 * @type {string}
	 */
	let sensorRssi = '-';
	/**
	 * 電池電圧
	 * @type {string}
	 */
	let sensorBattery = '-';

	/**
	 * センサーデータのストアを購読し、状態変数に反映する
	 * @type {import('svelte/store').Unsubscriber}
	 */
	const unsubscribe = sensorData.subscribe((value) => {
		const sensorData = value?.Data ?? {};
		connectCond = sensorData.SensorChildCondition ?? '-';
		sensorRssi =
			sensorData.SensorChildRSSI != null ? String(Math.round(sensorData.SensorChildRSSI)) : '-';
		sensorBattery =
			sensorData.SensorChildBatteryLevel != null
				? String(Math.round(sensorData.SensorChildBatteryLevel * 100) / 100)
				: '-';
	});

	/**
	 * コンポーネントの破棄時にストアの購読を解除する
	 */
	onDestroy(() => {
		unsubscribe();
	});
</script>

<div class="container">
	<!-- 左側のメニュー -->
	<div class="common-left-menu">
		<div class="common-menu-title">表示センサの選択</div>
		<div class="menu-inner-first-container">
			<div class="menu-content">
				<label class="hierarchybox">
					<select bind:value={selectedOption1}>
						{#each sensorNameOptions as option}
							<option value={option}>{option}</option>
						{/each}
					</select>
				</label>
				<p class="hierarchy1text">Aライン</p>
				<label class="hierarchybox">
					<select bind:value={selectedOption2}>
						{#each sensorNameOptions as option}
							<option value={option}>{option}</option>
						{/each}
					</select>
				</label>
				<p class="hierarchy2text">⑤RCTベアリング</p>
				<button class="button-first" on:click={handleButtonClick}>OK</button>
			</div>
		</div>
		<div class="menu-inner-second-container">
			<div class="second-lavel">通信状態(dBm)</div>
			<div class="second-value">{sensorRssi}</div>
			<div class="second-lavel">電池電圧(V)</div>
			<div class="second-value">{sensorBattery}</div>
		</div>
		{#if showGraphs}
			<button class="button-graph-on" on:click={toggleGraphs}>30日グラフ出力</button>
		{:else}
			<button class="button-graph-off" on:click={toggleGraphs}>30日グラフ出力</button>
		{/if}
		<button class="button-csv" on:click={downloadCSV} disabled={!showGraphs}
			>測定データダウンロード(CSV)</button
		>
	</div>

	{#if showGraphs}
		<div class="main-container-all">
			<div class="header">
				<div class="header-title">⑤RCTベアリング</div>
			</div>
			<div class="content-threshold-lavel">
				<iframe src={iframeSrcValue1} class="lavel-frame" title="値1"></iframe>
			</div>
			<div class="content-threshold-lavel">
				<iframe src={iframeSrcValue2} class="lavel-frame" title="値2"></iframe>
			</div>
			<div class="content-threshold-graph">
				<iframe src={iframeSrcGraph1} class="graph-frame" title="グラフ1"></iframe>
			</div>
			<div class="content-threshold-graph">
				<iframe src={iframeSrcGraph2} class="graph-frame" title="グラフ2"></iframe>
			</div>
		</div>
	{:else}
		<div class="main-container-part">
			<div class="header">
				<div class="header-title">⑤RCTベアリング</div>
			</div>
			<div class="content-threshold-lavel">
				<iframe src={iframeSrcValue1} class="lavel-frame" title="値1"></iframe>
			</div>
			<div class="content-threshold-lavel">
				<iframe src={iframeSrcValue2} class="lavel-frame" title="値2"></iframe>
			</div>
		</div>
	{/if}
</div>

<style>
	/* 全体の余白とスクロール設定をリセット */
	:global(html),
	:global(body) {
		margin: 0;
		padding: 0;
		height: 100%;
		overflow: hidden;
		font-size: 16px;
	}

	/* 全体レイアウト */
	.container {
		display: flex;
		height: 100vh;
		overflow: hidden;
	}

	/* メイン2列レイアウト */
	.main-container-part {
		display: grid;
		grid-template-columns: 1fr 1fr;
		grid-template-rows: 60px 1fr;
		gap: 10px;
		flex-grow: 1;
	}

	/* メイン2列＋2段レイアウト */
	.main-container-all {
		display: grid;
		grid-template-columns: 1fr 1fr;
		grid-template-rows: 60px 32% 60%;
		gap: 10px;
		flex-grow: 1;
	}

	/* ヘッダー */
	.header {
		grid-column: span 2;
		background-color: white;
	}

	/* ヘッダーのタイトル */
	.header-title {
		border: 3px solid #009999;
		padding: 5px;
		margin-left: 20px;
		display: inline-block;
		font-weight: bold;
		font-size: 1.6em;
		border-radius: 8px;
		width: 50%;
	}

	/* 閾値表示エリア */
	.content-threshold-lavel {
		background-color: white;
		padding: 10px;
		text-align: center;
	}

	/* グラフ表示エリア */
	.content-threshold-graph {
		background-color: white;
		padding: 10px;
		height: 100%;
		text-align: center;
	}

	/* メニューコンテンツ */
	.menu-content {
		padding: 16px;
		display: flex;
		flex-direction: column;
		gap: 10px;
		margin-right: -5px;
	}

	/* 最初のボタン */
	.button-first {
		width: 40%;
		padding: 8px 16px;
		background-color: #009999;
		color: white;
		border: none;
		cursor: pointer;
		align-self: flex-end;
		border-radius: 4px;
	}

	/* グラフ・CSVボタン共通 */
	.button-graph-on,
	.button-graph-off,
	.button-csv {
		width: auto;
		padding: 8px 16px;
		margin: 10px;
		border: 3px solid #009999;
		cursor: pointer;
		border-radius: 4px;
	}

	/* グラフONボタン */
	.button-graph-on {
		background-color: #009999;
		color: white;
	}

	/* グラフOFF・CSVボタン */
	.button-graph-off,
	.button-csv {
		background-color: white;
		color: black;
	}

	/* 無効なCSVボタン */
	.button-csv:disabled {
		opacity: 0.5;
		cursor: not-allowed;
	}

	/* セレクトボックスラッパー */
	.hierarchybox {
		display: inline-flex;
		align-items: center;
		position: relative;
	}

	/* セレクト装飾（四角） */
	.hierarchybox::before {
		position: absolute;
		right: 0px;
		width: 15px;
		height: 15px;
		background-color: #57a1f2;
		content: '';
		pointer-events: none;
	}

	/* セレクト装飾（三角） */
	.hierarchybox::after {
		position: absolute;
		right: 3px;
		width: 10px;
		height: 8px;
		background-color: white;
		clip-path: polygon(0 0, 100% 0, 50% 100%);
		content: '';
		pointer-events: none;
	}

	/* セレクト本体 */
	.hierarchybox select {
		appearance: none;
		min-width: 200px;
		height: 2.8em;
		padding: 0.4em calc(0.8em + 30px) 0.4em 0.8em;
		border: none;
		border-bottom: 2px solid #009999;
		background-color: #fff;
		color: #009999;
		font-size: 1em;
		font-weight: bold;
		cursor: pointer;
	}

	/* セレクトフォーカス時 */
	.hierarchybox select:focus {
		outline: none;
	}

	/* セレクトラベル（1階層目） */
	.hierarchy1text {
		margin-top: 0px;
		margin-left: 10px;
		margin-bottom: 3px;
	}

	/* セレクトラベル（2階層目） */
	.hierarchy2text {
		margin-top: 0px;
		margin-left: 10px;
		margin-bottom: 3px;
	}

	/* メニュー内第1コンテナ */
	.menu-inner-first-container {
		padding: 10px;
		background-color: #fcfefe;
		border-radius: 8px;
		margin: 10px;
	}

	/* メニュー内第2コンテナ */
	.menu-inner-second-container {
		padding: 10px;
		background-color: #fcfefe;
		border-radius: 8px;
		margin: 10px;
		text-align: center;
	}

	/* 閾値ラベル */
	.second-lavel {
		color: #00817e;
		font-size: 1em;
		font-weight: bold;
	}

	/* 閾値値 */
	.second-value {
		color: black;
		font-size: 1em;
		font-weight: bold;
	}

	/* ラベル用iframe */
	/* .lavel-frame {
    width: 100%;
    height: 100vh;
    border: none;
  } */

	/* グラフ用iframe */
	.graph-frame {
		width: 100%;
		border: none;
	}

	/* 共通iframeスタイル */
	iframe {
		width: 100%;
		height: 100%;
		border: none;
		display: block;
	}
</style>
