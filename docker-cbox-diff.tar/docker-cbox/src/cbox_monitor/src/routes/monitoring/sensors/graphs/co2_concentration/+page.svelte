<script>
	import GraphComponent from '$lib/components/SensorGraph.svelte';

	/**
	 * センサーデータを保持するプロパティ
	 * @type {any} 任意の形式のデータ（SensorGraphコンポーネントに渡される）
	 */
	export let data;
</script>

<!-- 
  @component GraphComponent
  @description センサーデータをグラフとして表示するコンポーネント
  @prop {any} data - 表示するセンサーデータ
-->
<GraphComponent {data} />
