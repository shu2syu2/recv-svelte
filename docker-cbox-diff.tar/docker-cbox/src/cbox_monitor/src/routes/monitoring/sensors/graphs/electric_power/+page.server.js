import { loadData } from '$lib/loadSensorGraphData.js';
import { getDateRange } from '$lib/utils/commonUtils.js';

/**
 * ページのサーバーサイドロード関数
 *
 * @function load
 * @description 指定された日数分のセンサーデータ（電力）を取得して返す
 * @param {Object} context - SvelteKitのロードコンテキスト
 * @param {URL} context.url - 現在のページのURLオブジェクト
 * @returns {Promise<ReturnType<typeof loadData>>} センサーデータの読み込み結果
 *
 * @see loadData
 * @see getDateRange
 */
export async function load({ url }) {
	const range = getDateRange(30);
	let start = range.start;
	let end = range.end;
	let title = '電力';
	let table = 'data_table';
	let column = '電力';

	return await loadData(table, column, start, end, title);
}
