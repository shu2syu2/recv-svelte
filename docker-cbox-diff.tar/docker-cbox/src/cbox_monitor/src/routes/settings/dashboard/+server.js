import { json } from '@sveltejs/kit';
import { pool } from '$lib/db.js';

/**
 * 日付を日本形式（YYYY-MM-DD）に整形するユーティリティ関数。
 *
 * @param {string | Date} date - 日付オブジェクトまたは文字列。
 * @returns {string} 整形された日付文字列。
 */
function formatDateJP(date) {
	const d = new Date(date);
	const pad = (n) => n.toString().padStart(2, '0');
	return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/**
 * 月別の電力使用量を取得するAPIエンドポイント。
 * クエリパラメータ `month=YYYY-MM` を受け取り、その月の日別電力量を返す。
 *
 * @param {Object} context - SvelteKitのリクエストコンテキスト。
 * @param {URL} context.url - リクエストURLオブジェクト。
 * @returns {Response} JSON形式のイベントデータ。
 */
export async function GET({ url }) {
	// クエリパラメータから月情報を取得（例："2025-03"）
	const monthStr = url.searchParams.get('month');
	if (!monthStr) {
		return new Response('Invalid parameters', { status: 400 });
	}

	// 年と月を分割して数値化
	const [y, m] = monthStr.split('-').map(Number);

	// 月初と月末の日付を生成
	const startDate = new Date(y, m - 1, 1); // 例: 2025-03-01
	const endDate = new Date(y, m, 0); // 例: 2025-03-31

	// 日本形式の日付文字列に変換
	const startISO = formatDateJP(startDate);
	const endISO = formatDateJP(endDate);

	/**
	 * SQLクエリの目的：
	 * - 指定月の各日の最新の「本日の電力量」データを取得。
	 * - ROW_NUMBER() を使って日付ごとに最新のレコードを1件抽出。
	 */
	const query =`
			SELECT 
				日時 AS day,
				ROUND("本日の電力量") AS usage
			FROM (
				SELECT *,
					ROW_NUMBER() OVER (
						PARTITION BY DATE("日時") 
						ORDER BY "日時" DESC
					) AS rn
				FROM public.data_table
				WHERE 
					"本日の電力量" IS NOT NULL
					AND DATE("日時") BETWEEN $1 AND $2
			) sub
			WHERE rn = 1
			ORDER BY "日時";
	`;
	const { rows } = await pool.query(query, [startISO, endISO]);
	console.log('月別電力使用量データ:', rows);

	/**
	 * FullCalendarなどで使用可能なイベント形式に変換。
	 * - title: 使用量（数値）
	 * - start: 日付（YYYY-MM-DD）
	 * - allDay: 終日イベントとして扱う
	 */
	const events = rows.map((r) => ({
		title: `${r.usage}`,
		start: formatDateJP(r.day),
		allDay: true
	}));

	return json({ events });
}
