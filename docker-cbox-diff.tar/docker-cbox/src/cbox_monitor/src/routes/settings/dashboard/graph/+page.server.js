import { pool } from '$lib/db.js';
import { CONSTANTS } from '$lib/constants.js';

/**
 * ページのサーバーサイドロード関数。
 * URLのクエリパラメータに基づいて、データベースから電力データを取得し、
 * グラフ描画に必要な形式で返却する。
 *
 * @function
 * @async
 * @param {Object} context - SvelteKitのロードコンテキスト。
 * @param {URL} context.url - クエリパラメータを含むURLオブジェクト。
 * @returns {Promise<Object>} グラフ描画に必要なデータとパラメータ。
 */
export async function load({ url }) {
	// クエリパラメータの取得
	const start = url.searchParams.get('dayStart');
	const end = url.searchParams.get('dayEnd');
	const period = url.searchParams.get('periodType');  // 集計単位（例：月別、日別）
	let aggregationType = url.searchParams.get('aggregationType'); // 集計方法（例：合計、階層別）
	let graphType = url.searchParams.get('graphType'); // グラフの種類（例：棒グラフ、積み立て）
	let dataType = 'single'; // データの形式（単一 or 複数）

	// 必須パラメータのチェック
	if (!start || !end) {
		return {
			status: 400,
			body: {
				error: 'Missing required parameters: dayStart or dayEnd'
			}
		};
	}

	// グループ化SQLの取得（デフォルトは日別）
	const groupBy =
		CONSTANTS.TYPES_PERIOD.find((t) => t.key === period)?.groupSql ??
		CONSTANTS.TYPES_PERIOD[1].groupSql;

	// データベースクエリの構築
	const query = `
			SELECT ${groupBy} AS date,
				SUM(電力) AS total,
				SUM(電力) AS electricpower
			FROM public.data_table
			WHERE DATE("日時") BETWEEN $1 AND $2
			AND 電力 is not null
			GROUP BY date
			ORDER BY date;
	`;
	console.log(`graph power sql= ${query} BETWEEN '${start}' AND '${end}'`);

	// クエリの実行
	const { rows } = await pool.query(query, [start, end]);
	console.log(`graph power data count= ${rows.length}`);

	// データ形式の決定
	dataType = aggregationType === 'grouped' ? 'single' : 'multiple';

	// グラフ種別に応じた調整
	if (graphType === 'bar') {
		aggregationType = 'grouped';
		graphType = 'bar';
	} else if (graphType === 'stacked') {
		aggregationType = graphType;
		graphType = 'bar';
	}

	// クライアントに返すデータ
	return {
		graphData: rows,
		start: start,
		end: end,
		period: period,
		aggregationType: aggregationType,
		graphType: graphType,
		dataType: dataType
	};
}
