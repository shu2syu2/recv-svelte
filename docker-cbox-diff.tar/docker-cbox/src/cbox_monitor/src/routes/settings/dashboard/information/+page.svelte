<script>
	// Svelteのライフサイクル関数
	import { onMount } from 'svelte';

	/**
	 * 表示用の年（例：2025）
	 * @type {string}
	 */
	let displayYear = '';

	/**
	 * 表示用の月（例：01）
	 * @type {string}
	 */
	let displayMonth = '';

	/**
	 * 電力使用量の下限（単位：kWh）
	 * @type {number}
	 */
	let lowerLimit = 2;

	/**
	 * 電力使用量の上限（単位：kWh）
	 * @type {number}
	 */
	let upperLimit = 5;

	/**
	 * 実際の電力使用量（単位：kWh）
	 * @type {number}
	 */
	let usageElectricity = 11000;

	/**
	 * CO2排出量（単位：kg）
	 * @type {number}
	 */
	let dischargeCO2 = 5500;

	/**
	 * 電気料金（単位：円）
	 * @type {number}
	 */
	let costElectricity = 330;

	/**
	 * コンポーネントのマウント時にURLパラメータから日付を取得し、
	 * 表示用の年と月に分割して格納する。
	 */
	onMount(() => {
		// URLクエリパラメータの取得
		const urlParams = new URLSearchParams(window.location.search);

		// "date" パラメータの取得（なければデフォルト値を使用）
		const displayDate = urlParams.get('date') ?? '2025-01-01';

		// 年と月に分割して格納
		const [y, m] = displayDate.split('-');
		displayYear = y;
		displayMonth = m;
	});
</script>

<div class="info-container">
	<div class="info-header">{displayYear}年 {displayMonth}月</div>
	<div class="info-filter-section">
		<div class="info-input-block">
			<button class="rabel-information">集計対象 絞り込み</button>
			<label
				>下限値 (kW):
				<input class="info-input-block-text" type="number" bind:value={lowerLimit} />
			</label>
			<span class="info-input-block-tilde">～</span>
			<label
				>上限値 (kW):
				<input class="info-input-block-text" type="number" bind:value={upperLimit} />
			</label>
		</div>
	</div>

	<div class="info-horizontal-boxes">
		<div class="info-stickynote-warn">電力使用量</div>
		<div class="info-value">{usageElectricity.toLocaleString()}</div>
		<div class="info-unit">kWh</div>
	</div>

	<div class="info-horizontal-boxes">
		<div class="info-stickynote-normal">CO2排出量</div>
		<div class="info-value">{dischargeCO2.toLocaleString()}</div>
		<div class="info-unit">kg</div>
	</div>
	<div class="info-horizontal-boxes">
		<div class="info-stickynote-normal">電気料金</div>
		<div class="info-value">{costElectricity.toLocaleString()}</div>
		<div class="info-unit">千円</div>
	</div>
</div>

<style>
	/* ページ全体の背景と余白をリセット */
	:global(body) {
		background-color: #f2f2f2;
		margin: 0;
		padding: 0;
	}

	/* 全体の情報表示コンテナ */
	.info-container {
		max-width: 600px;
		margin: 0 auto;
		padding: 1rem;
		font-family: sans-serif;
	}

	/* 年月のヘッダー表示 */
	.info-header {
		background-color: #ccc;
		padding: 0.5rem 1rem;
		font-size: 1.2rem;
		font-weight: bold;
		text-align: center;
		border-radius: 4px;
		margin-bottom: 1rem;
	}

	/* 絞り込みセクションのレイアウト */
	.info-filter-section {
		display: flex;
		justify-content: flex-start;
		align-items: flex-end;
		gap: 2rem;
		margin-bottom: 1.5rem;
		width: 100%;
	}

	/* 入力ブロックの横並び */
	.info-input-block {
		display: flex;
		align-items: flex-end;
		gap: 0.5rem;
		line-height: 1.2;
	}

	/* ラベルと入力の縦並び */
	.info-input-block label {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 0.5rem;
		font-size: 0.9rem;
		white-space: nowrap;
	}

	/* 数値入力フィールドのスタイル */
	.info-input-block-text {
		border: 1px solid black;
		border-radius: 4px;
		height: 1.4rem;
		width: 8rem;
		text-align: center;
		font-size: 0.9rem;
	}

	/* ～記号のスタイル */
	.info-input-block-tilde {
		font-size: 1.2rem;
		line-height: 1;
		display: flex;
		align-items: flex-end;
		padding-bottom: 0.4rem;
	}

	/* 絞り込みボタンのスタイル */
	.rabel-information {
		padding: 1px;
		font-weight: bold;
		font-size: 1em;
		border-radius: 9999px;
		width: 180px;
		height: 50px;
		border: 1px solid black;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	/* 情報表示用の付箋風ラベル（警告色） */
	.info-stickynote-warn {
		background-color: #ffc000;
	}

	/* 情報表示用の付箋風ラベル（通常色） */
	.info-stickynote-normal {
		background-color: #099999;
	}

	/* 共通の付箋スタイル */
	.info-stickynote-warn,
	.info-stickynote-normal {
		position: relative;
		width: 180px;
		height: 50px;
		overflow: hidden;
		color: white;
		font-size: 1.1em;
		font-weight: bold;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	/* 付箋の右下に折り返し風の装飾 */
	.info-stickynote-warn::after,
	.info-stickynote-normal::after {
		content: '';
		position: absolute;
		bottom: 0;
		right: 0;
		width: 15px;
		height: 15px;
		background: linear-gradient(255deg, rgba(255, 255, 255, 0.99), transparent);
		clip-path: polygon(100% 100%, 0% 100%, 100% 0%);
	}

	/* 数値表示部分のスタイル */
	.info-value {
		position: relative;
		width: 150px;
		height: 50px;
		font-size: 2em;
		color: #099999;
		font-weight: bold;
		display: flex;
		align-items: center;
		justify-content: right;
	}

	/* 単位表示部分のスタイル */
	.info-unit {
		position: relative;
		width: 100px;
		height: 50px;
		font-size: 1.5em;
		color: #7f7f7f;
		font-weight: bold;
		display: flex;
		align-items: flex-end;
		justify-content: right;
	}

	/* 横並びの情報ボックス */
	.info-horizontal-boxes {
		display: flex;
		gap: 10px;
		margin-top: 10px;
	}
</style>
