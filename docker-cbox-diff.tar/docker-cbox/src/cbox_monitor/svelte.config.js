import adapterAuto from '@sveltejs/adapter-auto';
import adapterNode from '@sveltejs/adapter-node';
import dotenv from 'dotenv';

/**
 * 環境変数を.envファイルから読み込む。
 *
 * @function
 * @description リクエスト処理時に動作するサーバーコードで使用される環境変数を設定するために使用。
 *             これにより、データベース接続情報やアダプターの種類を環境変数から取得できるようになります。
 */
dotenv.config();

const adapterType = process.env.PUBLIC_ADAPTER;

export default {
  kit: {
    adapter:
      adapterType === 'node'
        ? adapterNode()
        : adapterAuto()
  }
};
