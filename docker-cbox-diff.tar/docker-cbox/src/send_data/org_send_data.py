import socket
import time
import json
import datetime
import numpy as np

# サーバーの設定
#SERVER_HOST = '127.0.0.1'  # サーバーが動作するホスト
SERVER_HOST = 'node-server'  # サーバーが動作するホスト
SERVER_PORT = 65432  # サーバーのポート

MAX_RETRIES = 10
RETRY_INTERVAL = 5

# ローレンツ方程式のパラメータ
sigma = 10.0
rho = 28.0
beta = 8.0 / 3.0

# 初期値（適当に設定）
x, y, z = 20.0, 25.0, 30.0
dt = 0.01  # 時間ステップ


def handle_connection():
    global x, y, z
    retries = 0

    while retries < MAX_RETRIES:

        try:
            # ソケットの設定
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            print(f"接続試行 {retries + 1}/{MAX_RETRIES}...")
            sock.connect((SERVER_HOST, SERVER_PORT))
            print("サーバーに接続成功！")


            # 送信ループ
            while True:
                # ローレンツ方程式によるカオスな変動
                dx = sigma * (y - x) * dt
                dy = (x * (rho - z) - y) * dt
                dz = (x * y - beta * z) * dt

                x += dx
                y += dy
                z += dz

                # 温度と湿度の変動（スケール調整）
                temperature = 15 + (x % 15)  # 15 〜 30度
                humidity = 30 + (abs(y) % 40)  # 30 〜 70%

                # ランダムなカラー（カオス変動に基づく）
                #color_options = ['#FF0000', '#00FF00', '#0000FF']
                color_options = ['#ffffff', '#ffffff', '#ffffff']
                bgcolor_options = ['#c41a30', '#2f4f4f', '#092237']
                color_index = int(abs(z) % 3)  # 0, 1, 2 の範囲にする
                color = color_options[color_index]
                bgcolor = bgcolor_options[color_index]

                # データ取得日時
                date_s = datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S.%f')

                # 送信データを作成
                data = {
                    'temperature': round(temperature, 2),
                    'humidity': round(humidity, 2),
                    'color': color,
                    'bgcolor': bgcolor,
                    'date': date_s
                }

                # JSON形式で送信
                sock.sendall(json.dumps(data).encode('utf-8'))

                print(f"送信データ: {data}")

                # 5秒ごとに送信
                time.sleep(5)

        except (socket.error, ConnectionError) as e:
            print(f"接続失敗: {e}")
            retries += 1
            if retries < MAX_RETRIES:
                print(f"{RETRY_INTERVAL}秒後に再試行します...")
                time.sleep(RETRY_INTERVAL)
            else:
                print("最大リトライ回数に達しました。終了します。")
                return

handle_connection()


